package com.uu.ssm.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.uu.ssm.dao.UserDao;
import com.uu.ssm.entity.User;
import com.uu.ssm.service.UserService;

@Service
public class UserServiceImpl implements UserService{

	@Autowired
	private UserDao dao;
	
	@Override
	public List<User> find(User user) {
		return dao.find(user);
	}

}
