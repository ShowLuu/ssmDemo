package com.uu.ssm.service;

import java.util.List;

import com.uu.ssm.entity.User;

public interface UserService {

	public List<User> find(User user);
	
}
