package com.uu.ssm.entity;

import java.util.Date;

public class User {
	
	private String ID;
	private String username;
	private String password;
	private int enable;
	private Date createTime;
	private String descrip;
	private Date endTime;
	public String getID() {
		return ID;
	}
	public void setID(String iD) {
		ID = iD;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public int getEnable() {
		return enable;
	}
	public void setEnable(int enable) {
		this.enable = enable;
	}
	public Date getCreateTime() {
		return createTime;
	}
	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}
	public String getDescrip() {
		return descrip;
	}
	public void setDescrip(String descrip) {
		this.descrip = descrip;
	}
	public Date getEndTime() {
		return endTime;
	}
	public void setEndTime(Date endTime) {
		this.endTime = endTime;
	}
	@Override
	public String toString() {
		return "User [ID=" + ID + ", username=" + username + ", password=" + password + ", enable=" + enable
				+ ", createTime=" + createTime + ", descrip=" + descrip + ", endTime=" + endTime + "]";
	}
	
}
