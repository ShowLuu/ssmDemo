package com.uu.ssm.dao;

import java.util.List;

import com.uu.ssm.entity.User;

public interface UserDao {
	
	public List<User> find(User user);

}
