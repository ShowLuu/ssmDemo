package com.springboot.ssm.service;

import com.springboot.ssm.entity.User;

import java.util.List;

public interface UserService {

    List<User> findAlls();

}
