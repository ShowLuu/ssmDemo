package com.springboot.ssm.controller;

import com.springboot.ssm.dao.UserDao;
import com.springboot.ssm.entity.User;
import com.springboot.ssm.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class UserController {

    @Autowired
    private UserService service;
    @Autowired
    private UserDao dao;

    @RequestMapping("/index")
    public String index(){
        User user=new User();
        user.setId(1L);
        return dao.findAll(user).toString();
    }

    @RequestMapping("/indexs")
    public String indexs(){
        return service.findAlls().toString();
    }

}
