package com.springboot.ssm.service.impl;

import com.springboot.ssm.dao.UserDao;
import com.springboot.ssm.entity.User;
import com.springboot.ssm.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserServiceImpl implements UserService{

    @Autowired
    private UserDao dao;

    @Override
    public List<User> findAlls() {
        return dao.findAlls();
    }
}
